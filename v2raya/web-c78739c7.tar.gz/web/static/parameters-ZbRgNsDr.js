const o=`<h1 id="флаги-и-переменные-окружения">Флаги и переменные окружения</h1>
<p>У каждого флага есть одноимённая переменная окружения: для <code>--log-level</code> это <code>V2RAYA_LOG_LEVEL</code>. Юнит сервиса в Linux задаёт <code>V2RAYA_LOG_FILE</code> и читает <code>/etc/default/v2raya</code>; остальные параметры сохраняют значения по умолчанию. Таблица ниже получена от работающего сервиса и показывает объявленные значения по умолчанию, а не действующие значения; если значение по умолчанию пусто, оно вычисляется при запуске.</p>
<h2 id="хуки">Хуки</h2>
<p><code>--transparent-hook</code> задаёт исполняемый файл, который запускается до и после настройки и отключения прозрачного прокси, с аргументами <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>, <code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code> и <code>--v2raya-confdir=&lt;directory&gt;</code>. <code>--core-hook</code> запускается до и после запуска и остановки ядра, с аргументами <code>--stage</code> и <code>--v2raya-confdir</code>. Скрипты маршрутизации для <code>tun</code> при выключенном параметре <strong>Автоматическая маршрутизация</strong> задаются отдельно: <strong>Настроить скрипт маршрутизации</strong>.</p>
<h2 id="каталоги">Каталоги</h2>
<table>
<thead>
<tr>
<th>Что</th>
<th>Где</th>
</tr>
</thead>
<tbody><tr>
<td>конфигурация и <code>v2raya.db</code></td>
<td><code>--config</code>; по умолчанию <code>/etc/v2raya</code> в Linux и macOS, <code>%ProgramData%\\SYSTEM\\v2rayA</code> для сервиса Windows, <code>~/.config/v2raya</code> (или <code>%AppData%\\v2rayA</code>) в режиме lite</td>
</tr>
<tr>
<td>сгенерированная конфигурация ядра</td>
<td><code>config.json</code> в каталоге конфигурации</td>
</tr>
<tr>
<td>данные правил (<code>geoip.dat</code>, <code>geosite.dat</code>)</td>
<td><code>--v2ray-assetsdir</code>; иначе поиск ведётся в каталогах данных XDG (<code>/usr/share/v2raya</code>, <code>/usr/local/share/v2raya</code>, <code>~/.local/share/v2raya</code>), а скачанный файл попадает в пользовательский каталог; в Windows — каталог <code>data</code> установщика или каталог конфигурации</td>
</tr>
<tr>
<td>ядро</td>
<td><code>--v2ray-bin</code>; по умолчанию <code>v2raya_core</code> рядом с <code>v2raya</code> или в <code>PATH</code></td>
</tr>
<tr>
<td>журналы</td>
<td><code>--log-file</code> или <code>V2RAYA_LOG_FILE</code>, иначе консоль; системный юнит Linux использует <code>/var/log/v2raya/v2raya.log</code>, пользовательский юнит — <code>~/.local/state/v2raya/v2raya.log</code>, установщик Windows — <code>%TEMP%\\v2raya.log</code></td>
</tr>
</tbody></table>
`;export{o as default};
