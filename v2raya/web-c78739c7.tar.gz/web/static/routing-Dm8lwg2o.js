const e=`<h1 id="قوانین-مسیریابی">قوانین مسیریابی</h1>
<p>RoutingA زبان قوانین v2rayA است. <strong>تنظیمات → قوانین RoutingA</strong> ویرایشگر را باز می‌کند؛ این قوانین برای پورت قوانین (<code>20172</code>) در حالت RoutingA و برای پروکسی شفاف با سیاست <em>حالت تفکیک ترافیک مانند پورت قوانین است</em> اعمال می‌شوند. ورودی سفارشی متصل به RoutingA متن قوانین خودش را دارد؛ بخش مربوط به آن در ادامه آمده است.</p>
<h2 id="نحو">نحو</h2>
<p>در هر خط یک قانون بنویسید: شرط‌ها با <code>&amp;&amp;</code> به هم وصل می‌شوند و سپس <code>-&gt;</code> و یک خروجی می‌آید. قوانین از بالا به پایین تطبیق داده می‌شوند و اولین تطبیق اعمال می‌شود؛ <code>default:</code> خروجی هر ترافیکی را مشخص می‌کند که با هیچ قانونی تطبیق نداشته باشد. خطی که با <code>#</code> شروع شود، توضیح است. v2rayA چند قانون خودش را پیش از این قوانین قرار می‌دهد: نشانی سرورهای پروکسی و سرویس اعلان Apple مستقیم می‌روند و شرط <code>inboundTag(...)</code> جای محدودهٔ ورودی معمول قانون را می‌گیرد.</p>
<pre><code>default: proxy
domain(geosite:category-ads-all) -&gt; block
domain(geosite:cn) -&gt; direct
ip(geoip:private, geoip:cn) -&gt; direct
</code></pre>
<table>
<thead>
<tr>
<th>شرط</th>
<th>موارد تطبیق</th>
</tr>
</thead>
<tbody><tr>
<td><code>domain(...)</code></td>
<td><code>domain:</code> دامنه و زیردامنه‌هایش، <code>full:</code> تطبیق دقیق، <code>regexp:</code>، <code>geosite:&lt;category&gt;</code>، <code>ext:&quot;file.dat:tag&quot;</code>؛ مقدار بدون پیشوند مانند <code>example.com</code> به‌صورت زیررشته تطبیق داده می‌شود</td>
</tr>
<tr>
<td><code>ip(...)</code></td>
<td>یک نشانی، یک CIDR (IPv6 را در گیومه بگذارید: <code>ip(&quot;2001:db8::/32&quot;)</code>)، <code>geoip:&lt;code&gt;</code>، <code>ext:&quot;file.dat:tag&quot;</code></td>
</tr>
<tr>
<td><code>port(...)</code></td>
<td>پورت‌ها و بازه‌های پورت مقصد، <code>port(80, 443, 1000-2000)</code></td>
</tr>
<tr>
<td><code>sourcePort(...)</code></td>
<td>پورت‌های مبدأ</td>
</tr>
<tr>
<td><code>network(...)</code></td>
<td><code>tcp</code>، <code>udp</code></td>
</tr>
<tr>
<td><code>protocol(...)</code></td>
<td>پروتکل شناسایی‌شده با شنود: <code>http</code>، <code>tls</code>، <code>quic</code>، <code>bittorrent</code> (باید <strong>شنود ترافیک ورودی</strong> روشن باشد)</td>
</tr>
<tr>
<td><code>source(...)</code></td>
<td>نشانی‌ها و محدوده‌های CIDR مبدأ</td>
</tr>
<tr>
<td><code>inboundTag(...)</code></td>
<td>ورودی‌ای که اتصال از آن وارد شده است</td>
</tr>
</tbody></table>
<h2 id="خروجی-ها">خروجی‌ها</h2>
<p><code>proxy</code>، <code>direct</code> و <code>block</code> از پیش تعریف شده‌اند. هر گروه پروکسی دیگر، پس از اتصال یک عضو، با نام خودش به‌عنوان خروجی در دسترس است؛ در غیر این صورت قوانین اعمال نمی‌شوند. سرور SOCKS یا HTTP خارج از v2rayA یک بار تعریف می‌شود و مانند گروه به کار می‌رود (فایل <code>ext:</code> در پوشهٔ داده‌های قوانین قرار می‌گیرد):</p>
<pre><code>outbound: office = socks(address: 192.168.1.10, port: 1080)
outbound: gateway = http(address: 10.0.0.1, port: 8080, user: &#39;name&#39;, pass: &#39;secret&#39;)
domain(domain: corp.example) -&gt; office
</code></pre>
<h2 id="دسته-ها">دسته‌ها</h2>
<p>دسته‌های <code>geosite:</code> از <a href="https://github.com/v2fly/domain-list-community">domain-list-community</a> متعلق به v2fly و کدهای <code>geoip:</code> از <a href="https://github.com/v2fly/geoip">v2fly/geoip</a> می‌آیند؛ v2rayA در اولین راه‌اندازی هر فایلی را که موجود نباشد بارگیری می‌کند؛ بستهٔ نصب ممکن است نسخهٔ تهیه‌شدهٔ خودش را همراه داشته باشد. موارد پرکاربرد: <code>geosite:cn</code>، <code>geosite:geolocation-!cn</code>، <code>geosite:private</code>، <code>geosite:category-ads-all</code>، <code>geosite:greatfire</code>، <code>geosite:netflix</code>، <code>geosite:youtube</code>، <code>geosite:telegram</code>، <code>geosite:openai</code>؛ <code>geoip:cn</code>، <code>geoip:private</code> و کدهای کشورها. ویژگی، دسته را محدودتر می‌کند: <code>geosite:apple@cn</code>، <code>geosite:category-games@cn</code>.</p>
<p>نام‌هایی که فقط در نسخه‌های تهیه‌شده توسط Loyalsoldier وجود دارند (<code>gfw</code>، <code>apple-cn</code>، <code>google-cn</code>، <code>geoip:telegram</code>)، در این فایل‌ها نیستند؛ هسته آن‌ها را با خطای <code>illegal domain rule</code> یا <code>illegal ip rule</code> رد می‌کند. <strong>به‌روزرسانی GFWList</strong> آن نسخه را (از <code>v2rayA/dist-v2ray-rules-dat</code>) با نام <code>LoyalsoldierSite.dat</code> بارگیری می‌کند؛ سپس قوانین می‌توانند با <code>domain(ext:&quot;LoyalsoldierSite.dat:gfw&quot;)</code> از آن استفاده کنند.</p>
<h2 id="ویرایشگر">ویرایشگر</h2>
<p>در حالت فهرست، هر قانون با یک فرم ویرایش می‌شود؛ حالت متن شمارهٔ خط‌ها، رنگ‌بندی و بررسی هر خط را نشان می‌دهد. راهنمای کنار ویرایشگر نمونه‌ها را در محل مکان‌نما درج می‌کند و بخش <strong>الگوها</strong> مجموعه‌قوانین کامل برای سیاست‌های رایج دارد: یکی را بالای قوانین خود درج کنید یا کل قوانین را با آن جایگزین کنید. قوانین به‌صورت فایل متنی وارد و صادر می‌شوند.</p>
<p>الگوی روسیه دامنه‌های <code>geosite:category-ru</code> را مستقیم می‌فرستد، به‌جز دامنه‌های استثنایی که پیش از آن آمده‌اند و از پروکسی می‌گذرند؛ بقیهٔ ترافیک نیز از پروکسی می‌گذرد. این یک نسخهٔ ثابت از <a href="https://github.com/wywywywycloud/routinga-russia">routinga-russia</a> است و خودکار به‌روز نمی‌شود؛ فایل <code>geosite.dat</code> باید شامل <code>category-ru</code> باشد.</p>
<p>نشانی‌های IP روسیه (<code>geoip:ru</code>) و نام‌ها و نشانی‌های IP شبکهٔ محلی (<code>geosite:private</code>، <code>geoip:private</code>) نیز مستقیم متصل می‌شوند؛ استثناهای پروکسی اولویت دارند.</p>
<p>ذخیره کردن، هستهٔ در حال اجرا را با قوانین جدید دوباره بارگذاری می‌کند؛ اگر هسته آن‌ها را رد کند، v2rayA قوانین قبلی را برمی‌گرداند و خطای هسته را نشان می‌دهد که متن مشکل‌دار را مشخص می‌کند. هستهٔ متوقف‌شده قوانین را در راه‌اندازی بعدی دریافت می‌کند.</p>
<h2 id="ورودی-های-سفارشی">ورودی‌های سفارشی</h2>
<p>ورودی سفارشی متصل به RoutingA متن قوانین خودش را دارد که فقط برای همان ورودی اعمال می‌شود. این متن قانون می‌پذیرد، نه تعریف: خط‌های <code>default:</code> و <code>outbound:</code> نادیده گرفته می‌شوند و ترافیکی که با هیچ قانونی تطبیق نداشته باشد به گروه انتخاب‌شده در فرم می‌رود. برای تعیین مسیر بقیهٔ ترافیک، متن را با قانونی فراگیر مانند <code>network(tcp, udp) -&gt; direct</code> تمام کنید.</p>
`;export{e as default};
