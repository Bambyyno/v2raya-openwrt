const t=`<h1 id="inbounds-and-sharing">Inbounds and sharing</h1>
<p>An inbound is a port on which the core accepts connections from applications or other devices.</p>
<h2 id="built-in-inbounds">Built-in inbounds</h2>
<p><strong>Settings → Address and Ports</strong> sets them; 0 closes a proxy inbound and lets the API port be chosen at random.</p>
<table>
<thead>
<tr>
<th>Inbound</th>
<th>Default</th>
<th>Routing</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>20170</code></td>
<td>everything through <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>20171</code></td>
<td>everything through <code>proxy</code></td>
</tr>
<tr>
<td>SOCKS5 with rules</td>
<td>off</td>
<td>the rule port&#39;s mode</td>
</tr>
<tr>
<td>HTTP with rules</td>
<td><code>20172</code></td>
<td>the rule port&#39;s mode</td>
</tr>
<tr>
<td>VMess with rules</td>
<td>off</td>
<td>a VMess inbound for other devices; the page shows its share link</td>
</tr>
<tr>
<td>API</td>
<td>random</td>
<td>the core&#39;s own API, used by v2rayA for statistics and the balancer</td>
</tr>
</tbody></table>
<p>The proxy inbounds listen on <code>127.0.0.1</code>. <strong>Port Sharing</strong> (Settings → Proxy) makes them listen on all interfaces so phones and other machines on the LAN can use them; the API port stays on loopback. On a network you do not trust, add a custom inbound with a username and password for the other devices and close the built-in SOCKS and HTTP ports, which take no password, or block them in the firewall.</p>
<h2 id="custom-inbounds">Custom inbounds</h2>
<p><strong>Settings → Custom Inbound Ports</strong> adds SOCKS or HTTP inbounds with their own port, an optional username and password, and their own routing: either a fixed proxy group, or RoutingA rules written for that inbound, with the chosen group as the fallback (<code>default:</code> is ignored there). Two custom inbounds can therefore send traffic to two different groups, and an inbound whose rules end in <code>network(tcp, udp) -&gt; direct</code> bypasses the proxy for every application pointed at it.</p>
<p>The tag is the inbound&#39;s name in the core configuration and in <code>inboundTag(...)</code> conditions.</p>
<h2 id="docker-and-port-mapping">Docker and port mapping</h2>
<p>In a container started with <code>--network=host</code> the inbounds and the transparent proxy act on the host. With bridge networking, publish port 2017 and the inbound ports you use, and turn on Port Sharing so they listen on the container&#39;s interfaces; the transparent proxy then only sees the container. v2rayA cannot tell whether a mapped port is free on the host.</p>
`;export{t as default};
