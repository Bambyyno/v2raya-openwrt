const o=`<h1 id="문제-해결">문제 해결</h1>
<p>먼저 서비스 로그를 확인하세요. Linux 서비스 유닛으로 실행할 때는 <code>/var/log/v2raya/v2raya.log</code>, 유닛 자체의 출력은 <code>journalctl -u v2raya</code>, 그 외에는 <code>--log-file</code>로 지정한 경로에서 확인합니다. <strong>로그</strong> 페이지에서도 같은 로그 스트림을 볼 수 있습니다. <strong>로그 수준</strong> 설정을 조정하면 코어가 더 상세한 로그를 출력합니다. 생성된 코어 설정은 설정 디렉터리의 <code>config.json</code>입니다.</p>
<h2 id="코어가-시작되지-않음">코어가 시작되지 않음</h2>
<p><code>CORE_START_FAILED</code>는 <code>v2raya_core</code>를 실행하지 못했거나, 시작 직후 종료되었거나, <code>--core-startup-timeout</code> 안에 API 포트를 열지 못했다는 뜻입니다. 로그에서 그 앞의 줄을 보면 원인을 알 수 있습니다. 일반적인 원인은 다음과 같습니다.</p>
<ul>
<li><strong>코어 버전 불일치</strong> — 페이지 상단의 배너입니다. <code>v2raya_core</code>는 <code>v2raya</code>와 버전이 같아야 합니다. 대신 <code>xray</code>나 <code>v2ray</code> 바이너리를 사용하는 것은 허용되지 않습니다. 둘 다 같은 릴리스에서 설치하세요.</li>
<li><strong><code>illegal domain rule: geosite:...</code></strong> — 규칙이 <code>geosite.dat</code>에 없는 카테고리를 지정합니다. 사용 가능한 이름은 라우팅 섹션을 참고하세요.</li>
<li><strong>address already in use</strong> — 인바운드 포트를 다른 프로그램이 사용 중입니다. 주소 및 포트에서 변경하거나 다른 프로그램을 중지하세요. 포트 53은 다르게 처리됩니다. 사용 중이면 DNS 모듈은 해당 포트에서 리스너를 열지 않고 로그에 이를 남기며, macOS에서는 기존 리졸버가 계속 응답합니다.</li>
<li><strong><code>v2raya_core executable not found</code></strong> — 코어 실행 파일이 <code>v2raya</code>와 같은 디렉터리에도, <code>PATH</code>에 지정된 디렉터리에도 없습니다. <code>--v2ray-bin</code>을 지정하세요.</li>
</ul>
<h2 id="아무것도-연결되지-않음">아무것도 연결되지 않음</h2>
<ul>
<li>대시보드는 그룹과 구성원의 지연 시간을 표시합니다. 노드는 먼저 TCP로, 실패하면 UDP의 QUIC 패킷으로 확인하므로 UDP만 수신하는 서버(juicity, tuic, hysteria2)도 측정됩니다. <code>TIMEOUT</code>은 두 확인 모두 이 컴퓨터에서 서버에 도달하지 못했다는 뜻입니다. 다른 노드를 사용하거나 구독을 확인하세요.</li>
<li>인바운드 하나를 직접 테스트하세요: <code>curl -x socks5h://127.0.0.1:20170 https://example.com</code>. 이 명령은 성공하지만 투명 프록시가 작동하지 않으면, 노드 문제로 판단하기 전에 투명 프록시 설정, DNS 규칙, 투명 프록시가 트래픽을 보내는 그룹을 확인하세요.</li>
<li><code>redirect</code>나 <code>tproxy</code>를 사용한다면 Docker 또는 방화벽이 iptables 규칙을 덮어썼을 수 있습니다. 코어를 중지했다가 시작해 규칙을 다시 적용하세요.</li>
<li>Windows와 macOS에서 LAN 리졸버에 직접 DNS를 질의하는 애플리케이션은 TUN을 우회합니다.</li>
</ul>
<h2 id="규칙-데이터">규칙 데이터</h2>
<p>코어를 찾은 뒤 <code>geoip.dat</code>나 <code>geosite.dat</code> 없이 시작하면 GitHub에서 없는 파일을 다운로드하고, 다운로드에 실패하면 종료합니다. 파일을 규칙 데이터 디렉터리에 직접 복사하거나(매개변수 섹션 참고), 파일을 포함한 패키지를 설치하세요.</p>
<h2 id="업그레이드-후">업그레이드 후</h2>
<p>이전 릴리스의 BoltDB 데이터베이스는 처음 시작할 때 마이그레이션됩니다. 기존 파일은 <code>bolt.db.bak</code>으로 남으며(해당 이름이 이미 있으면 <code>bolt.db.bak.1</code>부터 번호 증가), 계정은 다시 등록해야 합니다. 업그레이드 전에 서비스를 중지하고 설정 디렉터리를 복사해 두세요. 그러면 복사본에서 마이그레이션을 다시 진행할 수 있습니다.</p>
<h2 id="비밀번호-재설정">비밀번호 재설정</h2>
<p>서비스를 중지하고, 서비스가 사용하는 계정으로 같은 <code>--config</code> 및 <code>--lite</code> 플래그를 지정해 <code>v2raya --reset-password</code>를 실행한 다음, 서비스를 다시 시작하고 등록하세요(Windows에서 서비스의 디렉터리는 관리자 권한으로 실행한 사용자의 디렉터리가 아니라 <code>%ProgramData%\\SYSTEM</code> 아래에 있음).</p>
`;export{o as default};
