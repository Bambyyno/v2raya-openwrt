const o=`<h1 id="گزینه-ها-و-متغیرهای-محیطی">گزینه‌ها و متغیرهای محیطی</h1>
<p>هر گزینه یک متغیر محیطی هم‌نام دارد: متغیر محیطی متناظر با گزینهٔ <code>--log-level</code>، <code>V2RAYA_LOG_LEVEL</code> است. واحد سرویس Linux، متغیر <code>V2RAYA_LOG_FILE</code> را تنظیم می‌کند و <code>/etc/default/v2raya</code> را می‌خواند؛ بقیهٔ گزینه‌ها مقدار پیش‌فرض خود را حفظ می‌کنند. جدول زیر از سرویس در حال اجرا خوانده می‌شود و پیش‌فرض‌های تعریف‌شده را نشان می‌دهد، نه مقادیر فعلی را؛ مقدار پیش‌فرض خالی هنگام راه‌اندازی محاسبه می‌شود.</p>
<h2 id="هوک-ها">هوک‌ها</h2>
<p><code>--transparent-hook</code> فایل اجرایی‌ای را مشخص می‌کند که پیش و پس از راه‌اندازی و برچیدن پروکسی شفاف، با آرگومان‌های <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>، <code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code> و <code>--v2raya-confdir=&lt;directory&gt;</code> اجرا می‌شود. <code>--core-hook</code> پیش و پس از راه‌اندازی و توقف هسته، با <code>--stage</code> و <code>--v2raya-confdir</code> اجرا می‌شود. اسکریپت‌های مسیریابی <code>tun</code> در حالت خاموش بودن <strong>مسیریابی خودکار</strong>، تنظیم جداگانه‌ای دارند: <strong>پیکربندی اسکریپت مسیریابی</strong>.</p>
<h2 id="پوشه-ها">پوشه‌ها</h2>
<table>
<thead>
<tr>
<th>مورد</th>
<th>محل</th>
</tr>
</thead>
<tbody><tr>
<td>پیکربندی و <code>v2raya.db</code></td>
<td><code>--config</code>؛ پیش‌فرض در Linux و macOS برابر با <code>/etc/v2raya</code>، برای سرویس Windows برابر با <code>%ProgramData%\\SYSTEM\\v2rayA</code> و در حالت lite برابر با <code>~/.config/v2raya</code> (یا <code>%AppData%\\v2rayA</code>) است</td>
</tr>
<tr>
<td>پیکربندی تولیدشدهٔ هسته</td>
<td><code>config.json</code> در پوشهٔ پیکربندی</td>
</tr>
<tr>
<td>داده‌های قوانین (<code>geoip.dat</code>، <code>geosite.dat</code>)</td>
<td><code>--v2ray-assetsdir</code>؛ در غیر این صورت پوشه‌های دادهٔ XDG جست‌وجو می‌شوند (<code>/usr/share/v2raya</code>، <code>/usr/local/share/v2raya</code>، <code>~/.local/share/v2raya</code>) و فایل بارگیری‌شده در پوشهٔ دادهٔ کاربر قرار می‌گیرد؛ در Windows، پوشهٔ <code>data</code> برنامهٔ نصب یا پوشهٔ پیکربندی</td>
</tr>
<tr>
<td>هسته</td>
<td><code>--v2ray-bin</code>؛ پیش‌فرض، <code>v2raya_core</code> در کنار <code>v2raya</code> یا در <code>PATH</code> است</td>
</tr>
<tr>
<td>گزارش‌ها</td>
<td><code>--log-file</code> یا <code>V2RAYA_LOG_FILE</code>، وگرنه کنسول؛ واحد سیستمی Linux از <code>/var/log/v2raya/v2raya.log</code>، واحد کاربری از <code>~/.local/state/v2raya/v2raya.log</code> و برنامهٔ نصب Windows از <code>%TEMP%\\v2raya.log</code> استفاده می‌کند</td>
</tr>
</tbody></table>
`;export{o as default};
