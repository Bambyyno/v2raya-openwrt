const o=`<h1 id="启动参数与环境变量">启动参数与环境变量</h1>
<p>每个参数都有同名的环境变量：<code>--log-level</code> 对应 <code>V2RAYA_LOG_LEVEL</code>。Linux 的服务单元设置了 <code>V2RAYA_LOG_FILE</code> 并读取 <code>/etc/default/v2raya</code>；其余保持默认。下表从正在运行的服务读取，显示的是声明的默认值而不是当前生效值；默认值为空的参数在启动时计算。</p>
<h2 id="钩子">钩子</h2>
<p><code>--transparent-hook</code> 指定一个可执行文件，在透明代理安装前后和卸载前后执行，参数为 <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>、<code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code> 与 <code>--v2raya-confdir=&lt;目录&gt;</code>。<code>--core-hook</code> 在内核启动前后和停止前后执行，参数为 <code>--stage</code> 与 <code>--v2raya-confdir</code>。<strong>自动路由</strong>关闭时 <code>tun</code> 使用的路由脚本是另一项设置：<strong>配置路由脚本</strong>。</p>
<h2 id="目录">目录</h2>
<table>
<thead>
<tr>
<th>内容</th>
<th>位置</th>
</tr>
</thead>
<tbody><tr>
<td>配置与 <code>v2raya.db</code></td>
<td><code>--config</code>；默认 Linux 与 macOS 为 <code>/etc/v2raya</code>，Windows 服务为 <code>%ProgramData%\\SYSTEM\\v2rayA</code>，lite 模式为 <code>~/.config/v2raya</code>（Windows 为 <code>%AppData%\\v2rayA</code>）</td>
</tr>
<tr>
<td>生成的内核配置</td>
<td>配置目录下的 <code>config.json</code></td>
</tr>
<tr>
<td>规则数据（<code>geoip.dat</code>、<code>geosite.dat</code>）</td>
<td><code>--v2ray-assetsdir</code>；未指定时按 XDG 数据目录查找（<code>/usr/share/v2raya</code>、<code>/usr/local/share/v2raya</code>、<code>~/.local/share/v2raya</code>），下载的文件放入用户的数据目录；Windows 为安装程序的 <code>data</code> 目录或配置目录</td>
</tr>
<tr>
<td>内核</td>
<td><code>--v2ray-bin</code>；默认为 <code>v2raya</code> 同目录或 <code>PATH</code> 中的 <code>v2raya_core</code></td>
</tr>
<tr>
<td>日志</td>
<td><code>--log-file</code> 或 <code>V2RAYA_LOG_FILE</code>，未指定时输出到控制台；Linux 系统单元使用 <code>/var/log/v2raya/v2raya.log</code>，用户单元使用 <code>~/.local/state/v2raya/v2raya.log</code>，Windows 安装程序使用 <code>%TEMP%\\v2raya.log</code></td>
</tr>
</tbody></table>
`;export{o as default};
