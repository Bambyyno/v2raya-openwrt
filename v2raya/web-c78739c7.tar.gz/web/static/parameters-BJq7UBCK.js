const o=`<h1 id="플래그와-환경-변수">플래그와 환경 변수</h1>
<p>모든 플래그에는 같은 이름의 환경 변수가 있습니다. <code>--log-level</code>에 해당하는 환경 변수는 <code>V2RAYA_LOG_LEVEL</code>입니다. Linux 서비스 유닛은 <code>V2RAYA_LOG_FILE</code>을 설정하고 <code>/etc/default/v2raya</code>를 읽습니다. 나머지는 기본값을 유지합니다. 아래 표는 실행 중인 서비스에서 읽어 오며, 실제 적용된 값이 아닌 선언된 기본값을 표시합니다. 기본값이 비어 있으면 시작 시 계산합니다.</p>
<h2 id="훅">훅</h2>
<p><code>--transparent-hook</code>은 투명 프록시의 설정 및 해제 전후에 실행할 실행 파일을 지정합니다. 인수로 <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>, <code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code>, <code>--v2raya-confdir=&lt;directory&gt;</code>를 전달합니다. <code>--core-hook</code>은 코어 시작 및 중지 전후에 실행하며, <code>--stage</code>와 <code>--v2raya-confdir</code>를 전달합니다. <strong>자동 라우트</strong>를 끈 <code>tun</code>의 라우트 스크립트는 별도 설정인 <strong>라우트 스크립트 구성</strong>에서 지정합니다.</p>
<h2 id="디렉터리">디렉터리</h2>
<table>
<thead>
<tr>
<th>항목</th>
<th>위치</th>
</tr>
</thead>
<tbody><tr>
<td>설정과 <code>v2raya.db</code></td>
<td><code>--config</code>. 기본값은 Linux와 macOS에서 <code>/etc/v2raya</code>, Windows 서비스에서 <code>%ProgramData%\\SYSTEM\\v2rayA</code>, lite 모드에서 <code>~/.config/v2raya</code>(또는 <code>%AppData%\\v2rayA</code>)</td>
</tr>
<tr>
<td>생성된 코어 설정</td>
<td>설정 디렉터리의 <code>config.json</code></td>
</tr>
<tr>
<td>규칙 데이터(<code>geoip.dat</code>, <code>geosite.dat</code>)</td>
<td><code>--v2ray-assetsdir</code>. 지정하지 않으면 XDG 데이터 디렉터리(<code>/usr/share/v2raya</code>, <code>/usr/local/share/v2raya</code>, <code>~/.local/share/v2raya</code>)를 검색하며, 다운로드한 파일은 사용자 데이터 디렉터리에 저장. Windows에서는 설치 프로그램의 <code>data</code> 디렉터리 또는 설정 디렉터리</td>
</tr>
<tr>
<td>코어</td>
<td><code>--v2ray-bin</code>. 기본값은 <code>v2raya</code>와 같은 디렉터리 또는 <code>PATH</code>에 지정된 디렉터리에 있는 <code>v2raya_core</code></td>
</tr>
<tr>
<td>로그</td>
<td><code>--log-file</code> 또는 <code>V2RAYA_LOG_FILE</code>, 없으면 콘솔. Linux 시스템 유닛은 <code>/var/log/v2raya/v2raya.log</code>, 사용자 유닛은 <code>~/.local/state/v2raya/v2raya.log</code>, Windows 설치 프로그램은 <code>%TEMP%\\v2raya.log</code> 사용</td>
</tr>
</tbody></table>
`;export{o as default};
