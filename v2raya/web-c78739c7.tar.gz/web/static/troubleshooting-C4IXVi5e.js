const e=`<h1 id="solução-de-problemas">Solução de problemas</h1>
<p>Consulte primeiro o registro do serviço: <code>/var/log/v2raya/v2raya.log</code> quando executado pela unidade de serviço do Linux, <code>journalctl -u v2raya</code> para o que a própria unidade imprime e, nos demais casos, o caminho definido por <code>--log-file</code>. A página <strong>Registros</strong> mostra o mesmo fluxo; a configuração <strong>Nível de registro</strong> aumenta o detalhamento do núcleo. A configuração gerada do núcleo é <code>config.json</code>, no diretório de configuração.</p>
<h2 id="o-núcleo-não-inicia">O núcleo não inicia</h2>
<p><code>CORE_START_FAILED</code> significa que não foi possível iniciar o <code>v2raya_core</code>, que ele encerrou logo após iniciar ou que não abriu sua porta de API dentro de <code>--core-startup-timeout</code>; as linhas anteriores no registro dizem o motivo. Causas comuns:</p>
<ul>
<li><strong>Incompatibilidade de versão do núcleo</strong> — o aviso no topo da página. O <code>v2raya_core</code> deve ter a mesma versão do <code>v2raya</code>; um binário <code>xray</code> ou <code>v2ray</code> em seu lugar não é aceito. Instale ambos da mesma versão publicada.</li>
<li><strong><code>illegal domain rule: geosite:...</code></strong> — uma regra indica uma categoria que não está em <code>geosite.dat</code>. Veja na seção de roteamento quais nomes existem.</li>
<li><strong>address already in use</strong> — uma porta de entrada está ocupada. Altere-a em Endereços e portas ou pare o outro programa. A porta 53 é diferente: quando está ocupada, o módulo DNS não abre seu serviço de escuta nessa porta e informa isso no registro; no macOS, o resolvedor existente continua respondendo.</li>
<li><strong><code>v2raya_core executable not found</code></strong> — o núcleo não está ao lado de <code>v2raya</code> nem em <code>PATH</code>; passe <code>--v2ray-bin</code>.</li>
</ul>
<h2 id="nada-se-conecta">Nada se conecta</h2>
<ul>
<li>O painel mostra o grupo e a latência de seus membros. Cada nó é sondado primeiro por TCP e, se falhar, por um pacote QUIC sobre UDP, de modo que servidores que só escutam UDP (juicity, tuic, hysteria2) também são medidos; <code>TIMEOUT</code> significa que nenhuma das sondagens alcançou o servidor desta máquina; tente outro nó ou verifique a assinatura.</li>
<li>Teste uma entrada diretamente: <code>curl -x socks5h://127.0.0.1:20170 https://example.com</code>. Se funcionar, mas o proxy transparente não, verifique a configuração do proxy transparente, as regras de DNS e o grupo para o qual o proxy transparente roteia antes de atribuir o problema ao nó.</li>
<li>Com <code>redirect</code> ou <code>tproxy</code>, o Docker ou um firewall pode ter substituído as regras do iptables; pare e inicie o núcleo para reinstalá-las.</li>
<li>No Windows e no macOS, um aplicativo que consulta DNS diretamente em um resolvedor da rede local não passa pelo TUN.</li>
</ul>
<h2 id="dados-de-regras">Dados de regras</h2>
<p>Ao iniciar, depois de localizar o núcleo, o v2rayA baixa do GitHub o arquivo <code>geoip.dat</code> ou <code>geosite.dat</code> que estiver ausente e encerra sua execução se o download falhar. Copie os arquivos manualmente para o diretório de dados de regras (veja a seção de parâmetros) ou instale um pacote que os inclua.</p>
<h2 id="após-uma-atualização">Após uma atualização</h2>
<p>Um banco de dados BoltDB de uma versão anterior é migrado na primeira inicialização; o arquivo antigo permanece como <code>bolt.db.bak</code> (<code>bolt.db.bak.1</code> e seguintes quando esse nome já está em uso), e as contas precisam ser registradas novamente. Pare o serviço e copie o diretório de configuração antes de atualizar; assim, a migração poderá ser repetida a partir dessa cópia.</p>
<h2 id="redefinir-a-senha">Redefinir a senha</h2>
<p>Pare o serviço, execute <code>v2raya --reset-password</code> com a conta usada pelo serviço e com as mesmas opções <code>--config</code> e <code>--lite</code> (no Windows, o diretório do serviço fica em <code>%ProgramData%\\SYSTEM</code>, não no diretório do usuário com privilégios elevados), inicie-o novamente e registre-se.</p>
`;export{e as default};
