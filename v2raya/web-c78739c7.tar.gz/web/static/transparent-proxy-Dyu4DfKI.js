const t=`<h1 id="透明代理">透明代理</h1>
<p>开启透明代理后，流量不经应用设置就进入内核，覆盖范围取决于实现方式。<strong>设置 → 透明代理/系统代理</strong>负责开启并选择分流策略，下面一项选择实现方式。</p>
<h2 id="分流策略">分流策略</h2>
<table>
<thead>
<tr>
<th>策略</th>
<th>走代理的流量</th>
</tr>
</thead>
<tbody><tr>
<td>不分流</td>
<td>全部</td>
</tr>
<tr>
<td>大陆白名单</td>
<td>除国内域名与地址（<code>geosite:cn</code>、<code>geoip:cn</code>）和私有地址以外的全部；国外站点、Google 与港澳地址即使命中国内规则也走代理</td>
</tr>
<tr>
<td>仅 GFWList</td>
<td>GFWList 上的域名（Loyalsoldier 文件中的 <code>gfw</code> 与 <code>greatfire</code>）和 Telegram 的地址段；先执行 <strong>更新 GFWList</strong>，没有该文件时无法选择此模式</td>
</tr>
<tr>
<td>与规则端口相同</td>
<td>规则端口的模式，包括 RoutingA</td>
</tr>
</tbody></table>
<h2 id="实现方式">实现方式</h2>
<table>
<thead>
<tr>
<th>实现</th>
<th>平台</th>
<th>说明</th>
</tr>
</thead>
<tbody><tr>
<td><code>redirect</code></td>
<td>Linux</td>
<td>iptables/nftables <code>REDIRECT</code>；只有 TCP；在<strong>服务与接管</strong>模式下，另把 53 端口的 DNS 重定向到内核的 DNS 模块（52353 端口）</td>
</tr>
<tr>
<td><code>tproxy</code></td>
<td>Linux</td>
<td>iptables/nftables <code>TPROXY</code>；TCP 与 UDP</td>
</tr>
<tr>
<td><code>tun</code></td>
<td>Linux、Windows、macOS</td>
<td>内核打开 TUN 设备；TCP 与 UDP；自动排除 v2rayA 与内核自身</td>
</tr>
<tr>
<td>系统代理</td>
<td>Windows；Linux 与 macOS 在非 root 运行（<code>--lite</code>）时可用</td>
<td>修改桌面的代理设置（Linux 上为 GNOME 与 KDE）；只覆盖遵守该设置的应用</td>
</tr>
</tbody></table>
<p><code>redirect</code> 与 <code>tproxy</code> 需要 root 和 <code>iptables</code> 或 <code>nftables</code>；<code>tun</code> 在 Linux 上需要 <code>/dev/net/tun</code> 与 <code>ip</code> 命令，在 Windows 与 macOS 上需要管理员权限。</p>
<p><strong>排除的网卡名前缀</strong>让从指定网卡进入的流量（Docker 网桥、VPN 隧道；默认为 <code>docker*</code>、<code>veth*</code>、<code>wg*</code>、<code>ppp*</code>）不经过 <code>redirect</code> 与 <code>tproxy</code>，在<strong>服务与接管</strong>模式下，它们的 DNS 仍会被拦截。</p>
<p><code>--redirect-respect-bound-device</code>（Linux）让用 <code>SO_BINDTODEVICE</code> 绑定到网卡的 TCP 连接绕过 <code>redirect</code>：NetworkManager 的联网检测就是这类连接，被重定向后会报告网络受限，依赖它的应用一直离线。默认关闭。打开后，服务通过 cgroup BPF 给这类连接打上 <code>0x80</code> 标记；这需要 5.14 及以上内核和 cgroup v2，缺少时 <code>redirect</code> 会启动失败。</p>
<h2 id="tun">TUN</h2>
<p>内核创建 TUN 设备并配置地址。<strong>自动路由</strong>开启时由 v2rayA 安装路由；在<strong>服务与接管</strong>模式下还会把系统解析器指向内核；关闭时由<strong>配置路由脚本</strong>里的安装与卸载脚本完成。</p>
<p>不会进入 TUN 的流量：内核自己的连接、<code>direct</code> 出站与 DNS 模块的上游查询（Linux 通过套接字标记，Windows 与 macOS 通过绑定物理网卡）。v2rayA 与内核始终被排除；<strong>TUN 自定义排除进程</strong>按可执行文件名排除更多进程，每行一个，只对能识别出所属进程的连接生效；在<strong>服务与接管</strong>模式下，这些进程的 DNS 仍由内核的 DNS 模块回答。比默认路由更精确的路由（直连网段、静态路由）同样不经过 TUN。</p>
<p>在<strong>服务与接管</strong>模式下，到达 TUN 的 53 端口明文 DNS 由内核的 DNS 模块按 DNS 规则回答；加密 DNS 不被拦截。此时 Windows 上系统解析器指向 TUN 网关，macOS 上指向内核在 <code>127.0.0.1</code> 的监听，后者要求 53 端口空闲。</p>
<p>在另外两种模式下 TUN 不建立该中继，两个平台的系统解析器也都不修改；仍然进入 TUN 的查询从设备直连发出。<strong>自动路由</strong>关闭、由路由脚本接管网络配置时同样如此：v2rayA 不修改解析器设置，DNS 也归脚本负责。</p>
<p>已知限制：Windows 与 macOS 上直接向局域网 DNS 查询的应用仍会绕过 TUN。</p>
<h2 id="dns">DNS</h2>
<p><strong>设置 → DNS 设置</strong>保存 DNS 模式与内核 DNS 模块遵循的规则。</p>
<table>
<thead>
<tr>
<th>模式</th>
<th>DNS 模块</th>
<th>系统查询</th>
</tr>
</thead>
<tbody><tr>
<td>关闭</td>
<td>不运行</td>
<td>不做任何改动</td>
</tr>
<tr>
<td>仅服务</td>
<td>运行</td>
<td>不做任何改动：解析器、防火墙的 DNS 规则与 TUN 中继都保持原样</td>
</tr>
<tr>
<td>服务与接管</td>
<td>运行</td>
<td>导向内核：改写解析器并导流 53 端口</td>
</tr>
</tbody></table>
<p>模式同时回答两个原本混在一起的问题：模块是否运行，以及系统的查询是否被导向它，<strong>仅服务</strong>对两者给出不同的答案。<strong>关闭</strong>与<strong>仅服务</strong>都让 53 端口的明文 TCP/UDP 在 <code>redirect</code>、<code>tproxy</code> 与系统代理下直通，在 <code>tun</code> 下直连发出；加密 DNS 本来就不会被送到内核，无需为此放弃接管。当已有其他程序把 DNS 指向 v2rayA 时选<strong>仅服务</strong>，不希望任何程序替你回答 DNS 时选<strong>关闭</strong>。</p>
<p>规则说明哪个上游回答哪些域名，查询是否直连。默认规则把私有域名交给 <code>127.0.0.1:53</code>（<code>localhost</code>，需要本机有解析器监听），<code>geosite:cn</code> 直连查询 <code>223.5.5.5</code>，其余经代理查询 <code>1.0.0.1</code>。出站为 <code>direct</code> 时直连查询；其他值都经本机的 SOCKS 入站发出，分流与 SOCKS 流量相同。域名列表为空的规则回答其他规则未命名的全部域名。上游写地址（<code>8.8.8.8</code>、<code>dns.google</code>）、<code>tcp://host</code>、<code>tls://host</code>（DNS over TLS）或 <code>https://host/dns-query</code>（DNS over HTTPS）；不支持 DNS over QUIC，保存时会拒绝。</p>
<p><strong>关闭</strong>会隐藏规则并保留它们：此时没有程序会读这些规则，丢掉它们会让重新开启模式时变成另一份配置。</p>
<p>保存把规则和模式写成两个请求，对话框会说明服务端接受了哪一个。规则已写入而模式被拒绝时会如实说明，重试因此只补上缺少的那一个。</p>
<h2 id="局域网共享">局域网共享</h2>
<p><strong>允许局域网的连接</strong>让 SOCKS、HTTP 与自定义入站监听所有网卡而不是 <code>127.0.0.1</code>，其他设备就能把这台机器当代理；API 端口仍只监听回环地址。要让它们的流量也经过透明代理，使用 <code>redirect</code>、<code>tproxy</code> 或 <code>tun</code>，打开 <strong>开启 IP 转发</strong>，不要把它们接入的网卡列入排除前缀，再把它们的默认网关指向这台机器；系统代理模式做不到这一点。</p>
`;export{t as default};
