const t=`<h1 id="투명-프록시">투명 프록시</h1>
<p>투명 프록시를 켜면 애플리케이션에서 별도로 설정하지 않아도 트래픽이 코어에 도달합니다. 적용 범위는 구현 방식에 따라 다릅니다. <strong>설정 → 투명 프록시/시스템 프록시</strong>에서 켜고 트래픽 분할 정책을 선택합니다. 그 아래 설정에서 구현 방식을 선택합니다.</p>
<h2 id="정책">정책</h2>
<table>
<thead>
<tr>
<th>정책</th>
<th>프록시를 통과하는 트래픽</th>
</tr>
</thead>
<tbody><tr>
<td>트래픽을 분할하지 않음</td>
<td>모든 트래픽</td>
</tr>
<tr>
<td>중국 사이트 외 프록시</td>
<td>중국 도메인과 주소(<code>geosite:cn</code>, <code>geoip:cn</code>), 사설 주소를 제외한 모든 트래픽. 중국 관련 규칙과 일치하더라도 중국 외 사이트, Google, 홍콩과 마카오 주소에는 프록시 적용</td>
</tr>
<tr>
<td>GFWList만 프록시</td>
<td>GFWList의 도메인(Loyalsoldier 파일의 <code>gfw</code>, <code>greatfire</code>)과 Telegram 주소 범위. 먼저 <strong>GFWList 업데이트</strong>를 실행해야 하며, 파일이 없으면 이 모드는 거부됨</td>
</tr>
<tr>
<td>규칙 포트와 동일</td>
<td>RoutingA를 포함한 규칙 포트의 모드</td>
</tr>
</tbody></table>
<h2 id="구현-방식">구현 방식</h2>
<table>
<thead>
<tr>
<th>구현 방식</th>
<th>플랫폼</th>
<th>참고</th>
</tr>
</thead>
<tbody><tr>
<td><code>redirect</code></td>
<td>Linux</td>
<td>iptables/nftables <code>REDIRECT</code>. TCP만 지원하며, <strong>서비스 및 가로채기</strong> 모드에서는 포트 53의 DNS도 코어의 DNS 모듈(포트 52353)로 리디렉션</td>
</tr>
<tr>
<td><code>tproxy</code></td>
<td>Linux</td>
<td>iptables/nftables <code>TPROXY</code>. TCP와 UDP 지원</td>
</tr>
<tr>
<td><code>tun</code></td>
<td>Linux, Windows, macOS</td>
<td>코어가 TUN 장치를 엽니다. TCP와 UDP 지원. v2rayA와 코어를 자동으로 제외</td>
</tr>
<tr>
<td>시스템 프록시</td>
<td>Windows. Linux와 macOS에서는 root 권한 없이 실행할 때(<code>--lite</code>)</td>
<td>데스크톱의 프록시 설정을 변경(Linux에서는 GNOME과 KDE). 해당 설정을 따르는 애플리케이션에만 적용</td>
</tr>
</tbody></table>
<p><code>redirect</code>와 <code>tproxy</code>에는 root 권한과 <code>iptables</code> 또는 <code>nftables</code>가 필요합니다. <code>tun</code>에는 Linux에서 <code>/dev/net/tun</code>과 <code>ip</code>가, Windows와 macOS에서 관리자 권한이 필요합니다.</p>
<p><strong>제외할 인터페이스 접두사</strong>는 지정한 인터페이스(Docker 브리지, VPN 터널. 기본값은 <code>docker*</code>, <code>veth*</code>, <code>wg*</code>, <code>ppp*</code>)로 들어오는 트래픽이 <code>redirect</code>와 <code>tproxy</code>를 거치지 않게 합니다. 해당 트래픽의 DNS는 <strong>서비스 및 가로채기</strong> 모드에서 가로채집니다.</p>
<p><code>--redirect-respect-bound-device</code>(Linux)는 <code>SO_BINDTODEVICE</code>로 인터페이스에 바인딩된 TCP 연결이 <code>redirect</code>를 거치지 않게 합니다. NetworkManager의 연결 확인이 이런 연결이며, 리디렉션되면 연결이 제한됨으로 보고되어 이에 의존하는 앱이 계속 오프라인 상태가 됩니다. 기본값은 꺼짐입니다. 켜면 서비스가 cgroup BPF로 이런 소켓에 <code>0x80</code> 마크를 붙이는데, 커널 5.14 이상과 cgroup v2가 필요하며 없으면 <code>redirect</code>가 시작되지 않습니다.</p>
<h2 id="tun">TUN</h2>
<p>코어가 TUN 장치를 생성하고 주소를 할당합니다. <strong>자동 라우트</strong>를 켜면 v2rayA가 라우팅 경로를 설정하고, <strong>서비스 및 가로채기</strong> 모드에서는 시스템 리졸버가 코어를 사용하도록 설정합니다. 끄면 <strong>라우트 스크립트 구성</strong>의 설정 및 해제 스크립트가 이 작업을 수행합니다.</p>
<p>코어 자체의 연결, <code>direct</code> 아웃바운드, DNS 모듈의 업스트림 질의는 TUN에 들어가지 않습니다(Linux에서는 소켓 마크를 사용하고, Windows와 macOS에서는 물리 인터페이스에 바인딩). v2rayA와 코어는 항상 제외됩니다. <strong>TUN 제외 프로세스</strong>에 실행 파일 이름을 한 줄에 하나씩 입력하면 소유 프로세스를 식별할 수 있는 연결을 추가로 제외합니다. <strong>서비스 및 가로채기</strong> 모드에서 해당 프로세스의 DNS는 여전히 코어의 DNS 모듈로 전달됩니다. 기본 라우트보다 구체적인 라우트(직접 연결된 네트워크, 정적 라우트)도 TUN을 우회합니다.</p>
<p><strong>서비스 및 가로채기</strong> 모드에서는 TUN에 도달한 포트 53의 암호화되지 않은 DNS에 코어의 DNS 모듈이 DNS 규칙에 따라 응답합니다. 암호화된 DNS는 가로채지 않습니다. 이때 Windows에서는 시스템 리졸버가 TUN 게이트웨이를 사용하도록 설정하고, macOS에서는 <code>127.0.0.1</code>의 코어 리스너를 사용하도록 설정하므로 포트 53이 비어 있어야 합니다.</p>
<p>나머지 두 모드에서는 TUN이 그런 릴레이를 만들지 않고 두 플랫폼 모두 시스템 리졸버를 변경하지 않습니다. 그래도 도착한 질의는 장치에서 직접 나갑니다. <strong>자동 라우트</strong>를 꺼서 라우팅 스크립트에 네트워크 구성을 맡긴 경우도 마찬가지입니다. v2rayA가 리졸버 설정을 바꾸지 않으므로 DNS 역시 스크립트의 몫입니다.</p>
<p>알려진 제한 사항: Windows와 macOS에서 LAN 리졸버에 직접 질의하는 애플리케이션은 여전히 TUN을 우회합니다.</p>
<h2 id="dns">DNS</h2>
<p><strong>설정 → DNS 설정</strong>에는 DNS 모드와 코어의 DNS 모듈이 따르는 규칙이 있습니다.</p>
<table>
<thead>
<tr>
<th>모드</th>
<th>DNS 모듈</th>
<th>시스템 질의</th>
</tr>
</thead>
<tbody><tr>
<td>끄기</td>
<td>실행 안 함</td>
<td>변경 없음</td>
</tr>
<tr>
<td>서비스만</td>
<td>실행</td>
<td>변경 없음: 시스템 리졸버, 방화벽의 DNS 규칙, TUN 릴레이 모두 그대로</td>
</tr>
<tr>
<td>서비스 및 가로채기</td>
<td>실행</td>
<td>모듈로 전달됨: 리졸버가 바뀌고 포트 53이 리디렉션됨</td>
</tr>
</tbody></table>
<p>모드는 원래 섞여 있던 두 가지 질문을 함께 답합니다. 모듈이 실행되는가, 그리고 시스템 질의가 모듈로 전달되는가입니다. <strong>서비스만</strong>은 두 질문에 서로 다르게 답합니다. <strong>끄기</strong>와 <strong>서비스만</strong>은 모두 <code>redirect</code>, <code>tproxy</code>, 시스템 프록시에서 53번 포트의 평문 TCP/UDP를 통과시키고, <code>tun</code>에서는 직접 내보냅니다. 암호화된 DNS는 원래 모듈로 전달되지 않으므로 그 때문에 가로채기를 포기할 필요가 없습니다. 다른 프로그램이 이미 DNS를 v2rayA로 보내고 있으면 <strong>서비스만</strong>을, DNS를 아예 대신 답해 줄 프로그램이 없어야 하면 <strong>끄기</strong>를 선택하세요.</p>
<p>규칙은 어떤 업스트림이 어떤 도메인에 응답할지, 질의를 직접 보낼지 지정합니다. 기본값은 내부 도메인 이름에 대한 DNS 질의를 <code>127.0.0.1:53</code>으로 보내고(<code>localhost</code>, 해당 주소에서 수신하는 리졸버 필요), <code>geosite:cn</code>은 <code>223.5.5.5</code>로 직접 보내며, 나머지는 프록시를 통해 <code>1.0.0.1</code>로 보냅니다. 아웃바운드가 <code>direct</code>이면 직접 질의합니다. 다른 값이면 로컬 SOCKS 인바운드를 통해 질의를 보내므로 SOCKS 트래픽과 같은 방식으로 라우팅됩니다. 도메인 목록이 비어 있는 규칙은 다른 규칙에서 지정하지 않은 모든 도메인에 응답합니다. 업스트림에는 주소(<code>8.8.8.8</code>, <code>dns.google</code>), <code>tcp://host</code>, DNS over TLS용 <code>tls://host</code>, DNS over HTTPS용 <code>https://host/dns-query</code>를 사용할 수 있습니다. DNS over QUIC는 지원하지 않으며 저장 시 거부됩니다.</p>
<p><strong>끄기</strong>는 규칙을 숨기지만 지우지는 않습니다. 어차피 읽는 프로그램이 없고, 지우면 모드를 다시 켤 때 다른 구성이 적용되기 때문입니다.</p>
<p>저장은 규칙과 모드를 두 개의 요청으로 쓰며, 대화상자는 서비스가 어느 쪽을 받아들였는지 알려줍니다. 규칙은 저장됐지만 모드가 거부되면 그 사실을 그대로 알리고, 다시 시도할 때는 아직 빠진 것만 보냅니다.</p>
<h2 id="lan-공유">LAN 공유</h2>
<p><strong>포트 공유</strong>를 켜면 SOCKS, HTTP, 사용자 지정 인바운드가 <code>127.0.0.1</code> 대신 모든 인터페이스에서 수신하므로 다른 장치가 이 컴퓨터를 프록시로 사용할 수 있습니다. API 포트는 계속 루프백에서 수신합니다. 다른 장치의 트래픽에도 투명 프록시를 적용하려면 <code>redirect</code>, <code>tproxy</code> 또는 <code>tun</code>을 사용하고, <strong>IP 포워딩</strong>을 켜고, 트래픽이 들어오는 인터페이스가 제외 접두사에 포함되지 않게 한 다음, 해당 장치의 기본 게이트웨이를 이 컴퓨터로 지정하세요. 시스템 프록시 모드에서는 이 기능을 사용할 수 없습니다.</p>
`;export{t as default};
