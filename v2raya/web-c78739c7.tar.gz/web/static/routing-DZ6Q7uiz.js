const e=`<h1 id="правила-маршрутизации">Правила маршрутизации</h1>
<p>RoutingA — язык правил v2rayA. Раздел <strong>Настройки → Правила RoutingA</strong> открывает редактор; правила применяются к порту правил (<code>20172</code>), когда для него выбран режим RoutingA, и к прозрачному прокси, когда для него выбран режим <em>Режим разделения трафика совпадает с режимом порта правил</em>. У пользовательского входящего порта, привязанного к RoutingA, свой текст правил; см. ниже.</p>
<h2 id="синтаксис">Синтаксис</h2>
<p>Одно правило в строке: условия, соединённые <code>&amp;&amp;</code>, затем <code>-&gt;</code> и исходящее подключение. Правила проверяются сверху вниз, применяется первое совпавшее; <code>default:</code> задаёт исходящее подключение для всего, что не подошло ни под одно правило. Строка, начинающаяся с <code>#</code>, — комментарий. v2rayA добавляет несколько собственных правил в начало: адреса прокси-серверов и служба push-уведомлений Apple идут напрямую, а условие <code>inboundTag(...)</code> заменяет обычное ограничение правила по входящим портам.</p>
<pre><code>default: proxy
domain(geosite:category-ads-all) -&gt; block
domain(geosite:cn) -&gt; direct
ip(geoip:private, geoip:cn) -&gt; direct
</code></pre>
<table>
<thead>
<tr>
<th>Условие</th>
<th>Соответствие</th>
</tr>
</thead>
<tbody><tr>
<td><code>domain(...)</code></td>
<td><code>domain:</code> — домен и его поддомены, <code>full:</code> — точное совпадение, <code>regexp:</code>, <code>geosite:&lt;category&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code>; значение без префикса, например <code>example.com</code>, ищется как подстрока</td>
</tr>
<tr>
<td><code>ip(...)</code></td>
<td>адрес, CIDR (IPv6 заключайте в кавычки: <code>ip(&quot;2001:db8::/32&quot;)</code>), <code>geoip:&lt;code&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code></td>
</tr>
<tr>
<td><code>port(...)</code></td>
<td>порты назначения и диапазоны, <code>port(80, 443, 1000-2000)</code></td>
</tr>
<tr>
<td><code>sourcePort(...)</code></td>
<td>порты источника</td>
</tr>
<tr>
<td><code>network(...)</code></td>
<td><code>tcp</code>, <code>udp</code></td>
</tr>
<tr>
<td><code>protocol(...)</code></td>
<td>протокол, определённый анализом трафика: <code>http</code>, <code>tls</code>, <code>quic</code>, <code>bittorrent</code> (нужно включить <strong>Анализ входящего трафика</strong>)</td>
</tr>
<tr>
<td><code>source(...)</code></td>
<td>адреса и диапазоны CIDR источника</td>
</tr>
<tr>
<td><code>inboundTag(...)</code></td>
<td>входящий порт, через который поступило соединение</td>
</tr>
</tbody></table>
<h2 id="исходящие-подключения">Исходящие подключения</h2>
<p><code>proxy</code>, <code>direct</code> и <code>block</code> встроены. Любая другая группа прокси становится исходящим подключением под своим именем, как только у неё появляется подключённый участник; иначе правила не применяются. Сервер SOCKS или HTTP вне v2rayA объявляется один раз и используется как группа (файл <code>ext:</code> помещается в каталог данных правил):</p>
<pre><code>outbound: office = socks(address: 192.168.1.10, port: 1080)
outbound: gateway = http(address: 10.0.0.1, port: 8080, user: &#39;name&#39;, pass: &#39;secret&#39;)
domain(domain: corp.example) -&gt; office
</code></pre>
<h2 id="категории">Категории</h2>
<p>Категории <code>geosite:</code> берутся из <a href="https://github.com/v2fly/domain-list-community">domain-list-community</a> проекта v2fly, а коды <code>geoip:</code> — из <a href="https://github.com/v2fly/geoip">v2fly/geoip</a>; при первом запуске v2rayA скачивает недостающие файлы, пакет может содержать собственную сборку этих файлов. Часто используются: <code>geosite:cn</code>, <code>geosite:geolocation-!cn</code>, <code>geosite:private</code>, <code>geosite:category-ads-all</code>, <code>geosite:greatfire</code>, <code>geosite:netflix</code>, <code>geosite:youtube</code>, <code>geosite:telegram</code>, <code>geosite:openai</code>; <code>geoip:cn</code>, <code>geoip:private</code> и коды стран. Атрибут сужает категорию: <code>geosite:apple@cn</code>, <code>geosite:category-games@cn</code>.</p>
<p>Имена, которые есть только в сборках Loyalsoldier (<code>gfw</code>, <code>apple-cn</code>, <code>google-cn</code>, <code>geoip:telegram</code>), отсутствуют в этих файлах; ядро отклоняет их с ошибкой <code>illegal domain rule</code> или <code>illegal ip rule</code>. Кнопка <strong>Обновить GFWList</strong> скачивает эту сборку (из <code>v2rayA/dist-v2ray-rules-dat</code>) как <code>LoyalsoldierSite.dat</code>, после чего правила могут использовать её как <code>domain(ext:&quot;LoyalsoldierSite.dat:gfw&quot;)</code>.</p>
<h2 id="редактор">Редактор</h2>
<p>В режиме списка каждое правило редактируется через форму; текстовый режим показывает номера строк, подсветку и результат проверки каждой строки. Справочник рядом с редактором вставляет примеры в позицию курсора, а раздел <strong>Шаблоны</strong> содержит полные наборы правил для распространённых режимов: вставьте один перед своими правилами или замените им весь набор. Правила импортируются и экспортируются в виде текстового файла.</p>
<p>Шаблон для России направляет <code>geosite:category-ru</code> напрямую, кроме перечисленных выше него доменов-исключений, которые идут через прокси. Остальной трафик тоже идёт через прокси. Это встроенный снимок <a href="https://github.com/wywywywycloud/routinga-russia">routinga-russia</a>, а не автоматически обновляемый список; для него нужен <code>geosite.dat</code> с категорией <code>category-ru</code>.</p>
<p>Российские IP-адреса (<code>geoip:ru</code>), локальные имена и IP-адреса (<code>geosite:private</code>, <code>geoip:private</code>) тоже направляются напрямую; домены-исключения имеют приоритет и идут через прокси.</p>
<p>При сохранении работающее ядро перезагружается с новыми правилами; если ядро их отклоняет, v2rayA возвращает предыдущие правила и показывает ошибку ядра с указанием некорректного текста. Остановленное ядро применяет правила при следующем запуске.</p>
<h2 id="пользовательские-входящие-порты">Пользовательские входящие порты</h2>
<p>У пользовательского входящего порта, привязанного к RoutingA, свой текст правил, действующий только для этого порта. Он принимает правила, а не определения: строки <code>default:</code> и <code>outbound:</code> игнорируются, а трафик, не подошедший ни под одно правило, идёт в группу, выбранную в форме. Завершите текст правилом для всего оставшегося трафика, например <code>network(tcp, udp) -&gt; direct</code>, чтобы самостоятельно задать его маршрут.</p>
`;export{e as default};
