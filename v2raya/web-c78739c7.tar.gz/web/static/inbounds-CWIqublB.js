const t=`<h1 id="入站与共享">入站与共享</h1>
<p>入站是内核接受应用或其他设备连接的端口。</p>
<h2 id="内置入站">内置入站</h2>
<p>在<strong>设置 → 地址与端口</strong>设置，0 表示关闭该代理入站；API 端口填 0 则随机选择。</p>
<table>
<thead>
<tr>
<th>入站</th>
<th>默认</th>
<th>分流</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>20170</code></td>
<td>全部走 <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>20171</code></td>
<td>全部走 <code>proxy</code></td>
</tr>
<tr>
<td>带规则的 SOCKS5</td>
<td>关闭</td>
<td>规则端口的模式</td>
</tr>
<tr>
<td>带规则的 HTTP</td>
<td><code>20172</code></td>
<td>规则端口的模式</td>
</tr>
<tr>
<td>带规则的 VMess</td>
<td>关闭</td>
<td>供其他设备连接的 VMess 入站；页面显示它的分享链接</td>
</tr>
<tr>
<td>API</td>
<td>随机</td>
<td>内核自己的 API，v2rayA 用它取统计数据和负载均衡状态</td>
</tr>
</tbody></table>
<p>代理入站监听 <code>127.0.0.1</code>。<strong>允许局域网的连接</strong>（设置 → 代理）让它们监听所有网卡，局域网里的手机和其他机器就能使用；API 端口仍只监听回环地址。在不受信任的网络中，为其他设备添加带用户名密码的自定义入站，并关闭不带密码的内置 SOCKS 与 HTTP 端口，或用防火墙拦住它们。</p>
<h2 id="自定义入站">自定义入站</h2>
<p><strong>设置 → 自定义入站端口</strong>添加 SOCKS 或 HTTP 入站，各自有端口、可选的用户名密码和独立的分流：绑定到固定的代理分组，或者为该入站单独写 RoutingA 规则，所选分组作为兜底（这里的 <code>default:</code> 被忽略）。两个自定义入站可以把流量送到两个不同的分组；规则以 <code>network(tcp, udp) -&gt; direct</code> 结尾的入站，让指向它的所有应用绕过代理。</p>
<p>标签是该入站在内核配置中的名称，也是 <code>inboundTag(...)</code> 条件里的名称。</p>
<h2 id="docker-与端口映射">Docker 与端口映射</h2>
<p>以 <code>--network=host</code> 启动的容器，入站与透明代理都作用于宿主机。使用桥接网络时，映射 2017 端口和用到的入站端口，并开启“允许局域网的连接”让入站监听容器的网卡；此时透明代理只能看到容器自身。v2rayA 无法判断映射的端口在宿主机上是否空闲。</p>
`;export{t as default};
